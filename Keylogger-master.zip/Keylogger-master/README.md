# Keylogger
A simple Keylogger created in Python using pynput library.
